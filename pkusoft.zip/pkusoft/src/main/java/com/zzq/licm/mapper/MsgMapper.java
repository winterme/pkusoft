package com.zzq.licm.mapper;

import com.zzq.licm.po.Msg;
import tk.mybatis.mapper.common.Mapper;

public interface MsgMapper extends Mapper<Msg> {
}