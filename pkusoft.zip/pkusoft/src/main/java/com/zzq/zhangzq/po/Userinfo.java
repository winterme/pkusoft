package com.zzq.zhangzq.po;

public class Userinfo {
    private String uid;

    private String username;

    private String pwd;

    private String userimg;

    /**
     * @return uid
     */
    public String getUid() {
        return uid;
    }

    /**
     * @param uid
     */
    public void setUid(String uid) {
        this.uid = uid;
    }

    /**
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return pwd
     */
    public String getPwd() {
        return pwd;
    }

    /**
     * @param pwd
     */
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    /**
     * @return userimg
     */
    public String getUserimg() {
        return userimg;
    }

    /**
     * @param userimg
     */
    public void setUserimg(String userimg) {
        this.userimg = userimg;
    }
}