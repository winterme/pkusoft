package com.zzq.zhangzq.mapper;

import com.zzq.zhangzq.po.Userinfo;
import tk.mybatis.mapper.common.Mapper;

public interface UserinfoMapper extends Mapper<Userinfo> {
}