var projectname = "";
var basepath = window.location.href.substr(0,window.location.href.indexOf(projectname)+projectname.length+1);
